### sprint
![[Pasted image 20201125134755.png]]
![[Pasted image 20201125134807.png]]
### sprint planning meeting
![[Pasted image 20201125134820.png]]
![[Pasted image 20201125134905.png]]
![[Pasted image 20201125135024.png]]
![[Pasted image 20201125135238.png]]
### daily Scrum (stand-up) meetings
![[Pasted image 20201125135253.png]]
![[Pasted image 20201125135317.png]]
![[Pasted image 20201125135328.png]]
### sprint review meetings
![[Pasted image 20201125135336.png]]
![[Pasted image 20201125135343.png]]
![[Pasted image 20201125135446.png]]
### retrospective meetings
![[Pasted image 20201125135502.png]]
![[Pasted image 20201125135545.png]]
![[Pasted image 20201125135554.png]]
### user stories
![[Pasted image 20201125135638.png]]
![[Pasted image 20201125135649.png]]
![[Pasted image 20201125135740.png]]
### the product backlog
![[Pasted image 20201125135807.png]]
![[Pasted image 20201125135823.png]]
![[Pasted image 20201125135830.png]]
![[Pasted image 20201125140004.png]]
![[Pasted image 20201125140030.png]]
### burndown charts 
![[Pasted image 20201125140049.png]]
![[Pasted image 20201125140057.png]]
![[Pasted image 20201125140146.png]]
### JUnit (unit testing)
![[Pasted image 20201125140338.png]]
### Jenkins
![[Pasted image 20201125140413.png]]
### Git/Github version control
![[Pasted image 20201125140435.png]]
### Gradle
![[Pasted image 20201125140450.png]]
